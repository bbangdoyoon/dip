import numpy as np

a = np.arange(4).reshape(-1, 2)
b = np.arange(2)

c = a+b
print(c)