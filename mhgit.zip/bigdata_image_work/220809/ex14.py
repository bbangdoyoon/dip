import numpy as np

aa = np.load('mya.npy')
print(aa)