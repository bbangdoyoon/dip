import cv2
import numpy as np

img = cv2.imread('20220811/white.jpg', cv2.IMREAD_COLOR)
