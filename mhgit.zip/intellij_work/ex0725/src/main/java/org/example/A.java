package org.example;

public class A {

    public void  doA(){
        System.out.println("doA");
    }
}
