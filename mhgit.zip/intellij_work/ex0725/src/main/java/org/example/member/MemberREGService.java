package org.example.member;

public class MemberREGService {
}
