package org.example;

public class Ex05 {

    public static void main(String[] args) {
        String str = null;
        if (str ==null)
            str = "";
        System.out.println(str.length());
    }
}
