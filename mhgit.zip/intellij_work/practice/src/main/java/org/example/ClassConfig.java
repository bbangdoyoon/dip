package org.example;

public class ClassConfig {
}
