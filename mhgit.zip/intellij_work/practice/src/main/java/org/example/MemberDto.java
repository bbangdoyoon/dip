package org.example;

public class MemberDto {

    private String name;

    private String email;

    private String pwd;

    public MemberDto(String name, String email, String pwd){

    }

}
