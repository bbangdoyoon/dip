package org.example;

public class MemberPrinter {
}
