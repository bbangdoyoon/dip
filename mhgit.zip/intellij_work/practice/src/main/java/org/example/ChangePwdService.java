package org.example;

public class ChangePwdService {
    public void chpwd() {
    }
}
