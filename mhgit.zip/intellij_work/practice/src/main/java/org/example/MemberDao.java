package org.example;

public class MemberDao {
    public void insert() {
        System.out.println("삽입");
    }

    public void selectaoll() {
        System.out.println("보기");
    }
}
