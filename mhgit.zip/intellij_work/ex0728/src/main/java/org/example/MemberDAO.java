package org.example;

public class MemberDAO {
    public void insert() {
        System.out.println("삽입");
    }

    public void selectall() {
        System.out.println("보기");
    }

    public void update() {
        System.out.println("수정");
    }
}
