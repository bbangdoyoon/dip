package org.example;

import java.util.Scanner;

public class Main1 {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        while(true){
            System.out.println("Hello world");
            System.out.println("입력하세요");
            scan.nextInt();
        }
    }

}
