package org.example;

public class Greeter {
    public void hi(){
        System.out.println("안녕하세요.");
    }
}
